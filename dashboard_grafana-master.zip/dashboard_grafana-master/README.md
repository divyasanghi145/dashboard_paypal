# dashboard_grafana

GRAFANA is UI for TSDB to query metrics and display them in graphs. TSDB metric name consists of profile name, application name, function, resolution which is very useful to find relevant information.
This repository consists of dashboard to display monitoring values useful while debugging in activities team.
It consists of services actsearchserv, paymentactdetailsserv, invoiceactivitysearchserv with graphs representing TPM(transactions per minute), EPM( errors per minute with CAL status 1 and CAL status 2) , Latency( min,max, avg) graphs on opentsdb data.
Dashboard:  https://engineering.paypalcorp.com/sherlock/grafana/dashboard/db/final-presentation

There are 4 dashboards refering to <br/>
READ: actsearchserv, paymentactdetailsserv  https://engineering.paypalcorp.com/sherlock/grafana/dashboard/db/ds_read <br/>
WRITE: activityprocessorserv, activityaggregatorserv, activityplatformserv https://engineering.paypalcorp.com/sherlock/grafana/dashboard/db/ds_write <br/>
C++ SERVICES: moneysearchserv, invoiceactivitysearchserv https://engineering.paypalcorp.com/sherlock/grafana/dashboard/db/c-services <br/>
DAEMONS: amqacteventsd, amqactpaymentsd, amqactivitieswebhooksd https://engineering.paypalcorp.com/sherlock/grafana/dashboard/db/daemons

They contain graphs on TPM, EPM, Latency for READ, WRITE AND C++ SERVICES. <br/>
DAEMONS contain graphs on ENQUEUE_RQ, ENQUEUE_EX, DEQUEUE_Q, Latency.
